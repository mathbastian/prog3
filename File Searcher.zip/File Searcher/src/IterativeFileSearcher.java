import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class IterativeFileSearcher implements IFileSearcher {

	public File findByName(File root, String name) {
		
		List<File> files = arrayToList( root.listFiles() );
		
		for ( File file : files ){
			if( file.isDirectory() ){
				files.addAll( arrayToList(file.listFiles()) );
			} 
			else{
				if(file.getName().equals(name)){
					return file;
				}
			}
		}
		
		return null;
	}
	
	private List<File> arrayToList ( File[] filesAsArray ){
		List<File> files = new ArrayList<File>();
		for (File file : filesAsArray) {
			files.add(file);
		}
		
		return files;
	}

}
