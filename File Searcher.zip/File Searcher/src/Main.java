import java.io.File;

public class Main {

	public static void main(String[] args) {
		
		String fileName = "install.txt";
		String root 	= "C:/wamp";
		File file = new File(root);
		
		//Recursive
		IFileSearcher searcher = new RecursiveFileSearcher();
		
		File found = searcher.findByName(file, fileName);

		if( found != null ){
			System.out.println( found.getPath() );
		} else{
			System.out.println("couldn't find file named " + fileName );
		}
		
		//Iterative
		searcher = new IterativeFileSearcher();
		
		found = searcher.findByName(file, fileName);
		
		if( found != null ){
			System.out.println( found.getPath() );
		} else{
			System.out.println("couldn't find file named " + fileName );
		}
	}

}

