import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;

public class RecursiveFileSearcher implements IFileSearcher {
	
	public File findByName( File root, String name ){
		
		for ( File file : root.listFiles()){
			
			if( file.isDirectory() ){
				
				findByName( file, name );
				
			} else{
				
				if(file.getName().equals(name)){
					return file;
				}
				
			}
			
		}
		
		return null;
		
	}
	
}