import javax.swing.JFrame;

import screen.*;

public class Main {

	public static void main(String[] args) {

		JFrame gui = new GUI();

	}

}