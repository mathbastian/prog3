package screen;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import controllers.MouseListenerImp;

public class GUI extends JFrame implements MouseListener {
	
	JTextArea pathToFile = new JTextArea();
	JTextArea textToBeDisplayed = new JTextArea();

	public GUI() {
		build();
	}
	
	private void build(){
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container container = getContentPane();
		
		JButton loadButton = new JButton("Carregar");
		loadButton.addMouseListener( this ); //new MouseListenerImp()
		
		JScrollPane scrollPane = new JScrollPane(textToBeDisplayed);
		
		container.add( pathToFile, BorderLayout.NORTH);
		container.add( loadButton, BorderLayout.WEST );
		container.add( scrollPane, BorderLayout.CENTER);
		
		setSize(600, 400);
		setVisible(true);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		textToBeDisplayed.setText("");
		File file = new File(this.pathToFile.getText());
		loadFile(file);
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	private void loadFile(File file){
		
		if (!file.isDirectory() && file.exists()) {

			try {
				FileReader fileReader = new FileReader(file.getPath());
				BufferedReader bufferedReader = new BufferedReader(fileReader);
				String line;
				
				try {
					while ( (line = bufferedReader.readLine()) != null) {
						textToBeDisplayed.append(line + "\n");
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
			
		}
		
	}
	
}
