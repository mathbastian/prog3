package searcher;

import java.io.File;

public interface IFileSearcher {

	public File findByName( File root, String name );
}
