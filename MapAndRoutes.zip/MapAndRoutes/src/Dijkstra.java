import java.awt.Color;
import java.awt.Graphics;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Set;

import javax.swing.JFrame;

public class Dijkstra {
	
	public void printBestRoute( JFrame frame, File file, MapPrinter mapPrinter, City sourceCity, City targetCity ) {
				
		Graph graph = assembleGraph(file);
		graph = calculateShortestPathFromSource(graph,
												findNodeByName(graph.getNodes(), sourceCity.getName()));
		
		repaint(frame, file, mapPrinter); //solution to repaint all map...		
		
		printRouteAndDistances(sourceCity, targetCity, frame.getGraphics(), graph);
				
	}
	
	private void repaint( JFrame frame, File file, MapPrinter mapPrinter ){
		frame.paintComponents(frame.getGraphics());
		mapPrinter.print(frame.getGraphics(), file);
		
	}
	
	private void printRouteAndDistances(City sourceCity, City targetCity, Graphics graphics, Graph graph) {
		Node sourceNode = findNodeByName(graph.getNodes(), sourceCity.getName());
		Node targetNode = findNodeByName(graph.getNodes(), targetCity.getName());

		for (Node node : targetNode.getShortestPath()) {
			graphics.setColor(Color.GREEN);
			graphics.drawLine(sourceNode.getX(), sourceNode.getY(),
							  node.getX(), node.getY());
			graphics.setColor(Color.BLACK);
			graphics.drawString(node.getDistance().toString(), node.getX()-10, node.getY()-15);
			sourceNode = node;			
		}
		
		if ( targetNode.getShortestPath().size() > 0 ){
			
			graphics.setColor(Color.GREEN);
			graphics.drawLine(sourceNode.getX(), sourceNode.getY(),
							  targetNode.getX(), targetNode.getY());
			graphics.setColor(Color.BLACK);
			graphics.drawString(targetNode.getDistance().toString(), targetNode.getX()-10, targetNode.getY()-15);
			
		}
		
	}
	
	private Graph calculateShortestPathFromSource( Graph graph, Node sourceNode ) {
		
		sourceNode.setDistance(0);
		
		Set<Node> settledNodes = new HashSet<>();
		Set<Node> unsettledNodes = new HashSet<>();
		
		unsettledNodes.add(sourceNode);
		
		while( unsettledNodes.size() != 0 ) {
			
			Node currentNode = getLowestDistanceNode(unsettledNodes);
			unsettledNodes.remove(currentNode);
			
			for ( Entry<Node, Integer> adjacencyPair : currentNode.getAdjacentNodes().entrySet()) {
				Node adjacentNode = adjacencyPair.getKey();
				Integer edgeWeight = adjacencyPair.getValue();
				
				if(settledNodes.contains(adjacentNode) == false) {
					calculateMinimumDistance(adjacentNode, edgeWeight, currentNode);
					unsettledNodes.add(adjacentNode);
				}
			}
			settledNodes.add(currentNode);
			
		}
		
		return graph;
	
	}
	
	private Node getLowestDistanceNode(Set<Node> unsettledNodes) {
		
		Node lowestDistanceNode = null;
		int lowestDistance = Integer.MAX_VALUE;
		
		for ( Node node : unsettledNodes ) {
			int nodeDistance = node.getDistance();
			if (nodeDistance < lowestDistance) {
				lowestDistance = nodeDistance;
				lowestDistanceNode = node;
			}
		}
		return lowestDistanceNode;
	}
	
	private void calculateMinimumDistance(Node evaluationNode, Integer edgeWeight, Node sourceNode) {
		Integer sourceDistance = sourceNode.getDistance();
		
		if (sourceDistance + edgeWeight < evaluationNode.getDistance()) {
			evaluationNode.setDistance(sourceDistance + edgeWeight);
			LinkedList<Node> shortestPath = new LinkedList<>(sourceNode.getShortestPath());
			shortestPath.add(sourceNode);
			evaluationNode.setShortestPath(shortestPath);
		}
	}
 
	private Graph assembleGraph(File file) {
				
		return addMissingDestinationsToGraph( addDestinationsToNodesOfGraph(file, buildGraphWithNodes(file)));

	}
	
	private Graph buildGraphWithNodes(File file) {
		
		Graph graph = new Graph();
		
		try {
			FileReader fileReader = new FileReader(file.getPath());
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line;
			Node currentNode = new Node("");
		
			try { //reading txt
				
				while ( (line = bufferedReader.readLine()) != null &&
						 !line.equals("")) {
					
					String[] splitLine = line.split(" ");
					currentNode = new Node(splitLine[0], //name
										   Integer.parseInt(splitLine[1]), // x
										   Integer.parseInt(splitLine[2])); // y
					graph.addNode(currentNode);
						
				}
				
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		return graph;
		
	}
	
	private Graph addDestinationsToNodesOfGraph(File file, Graph graph) {

		Set<Node> nodes = graph.getNodes();
		
		try {
			FileReader fileReader = new FileReader(file.getPath());
			@SuppressWarnings("resource")
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line;
			Node currentNode;
		
			try { //reading txt
				
				for( int i = 0; i < 104 ; i++ ) {

					line = bufferedReader.readLine();
					
					if(i<44) {
						continue; //only city names and positions
					}
					else {
						String[] splitLine = line.split(" ");
						currentNode = findNodeByName(nodes, splitLine[0]);
						currentNode.addDestination( findNodeByName(nodes, splitLine[1]), 
													Integer.parseInt(splitLine[2]));
						
					}
				}
				
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		return graph;
	}
	
	private Node findNodeByName(Set<Node> nodes, String name) {
		
		for ( Node node : nodes ) {
			if(node.getName().equals(name)) {
				return node;
			}
		}
		
		return null;
		
	}
	
	private Graph addMissingDestinationsToGraph(Graph graph){
		
		for (Node node : graph.getNodes()) {
			
			for (Entry <Node, Integer> adjacentNode : node.getAdjacentNodes().entrySet()) {
				if ( !adjacentNode.getKey().getAdjacentNodes().containsKey(node) ){
					
					adjacentNode.getKey().addDestination(node, adjacentNode.getValue());
				}
			}
			
		}
		
		return graph;
	}

}