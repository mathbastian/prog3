import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

@SuppressWarnings("serial")
public class GUI extends JFrame implements ActionListener {
	
	private File selectedFile;
	MapPrinter mapPrinter = new MapPrinter();
	
	private JComboBox<String> sourceCitiesList;
	private JComboBox<String> targetCitiesList;
	
	private List<City> cities;
	
	public GUI() {
		build();
	}
	
	private void build() {
		
		setLayout( new BorderLayout() );
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		Container container = getContentPane();
		
		JMenuBar upperMenuBar = new JMenuBar();
		JMenuBar lowerMenuBar = new JMenuBar();
		
		JMenu menuFile = new JMenu("File");
		
		JMenuItem menuLoadMap = new JMenuItem("Load Map");
		
		sourceCitiesList = new JComboBox<String>();
		targetCitiesList = new JComboBox<String>();
		
		menuLoadMap.addActionListener( new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser( GUI.class.getProtectionDomain().getCodeSource().getLocation().getPath());
				int returnValue = fileChooser.showOpenDialog(container);
				
				if (returnValue == JFileChooser.APPROVE_OPTION) {
					selectedFile = fileChooser.getSelectedFile();
					mapPrinter.print(getGraphics(), selectedFile);
					
					cities = mapPrinter.getCities(selectedFile);
					
					for(City city : cities) {
						
						String label = new String(city.getName() +
													   " " +
													   city.getX() + 
													   " " +
													   city.getY());
						sourceCitiesList.addItem(label);
						targetCitiesList.addItem(label);
						
					}
					
				}
			}
		});
				
		menuFile.add(menuLoadMap);
		
		upperMenuBar.add(menuFile);
		
		JButton routeButton = new JButton("Trace route");		
		routeButton.addActionListener( this );
		
		lowerMenuBar.add(sourceCitiesList);
		lowerMenuBar.add(targetCitiesList);
		lowerMenuBar.add(routeButton, BorderLayout.EAST);
		
		container.add(upperMenuBar, BorderLayout.NORTH);
		container.add(lowerMenuBar, BorderLayout.SOUTH);
						
		setSize(1000, 800);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if ( e.getSource().getClass() == JButton.class) { // trace route
						
			MapPrinter mapPrinter = new MapPrinter();
			Dijkstra dijkstra = new Dijkstra();
			
			String sourceCity = sourceCitiesList.getSelectedItem().toString().split(" ")[0];
			String targetCity = targetCitiesList.getSelectedItem().toString().split(" ")[0];
						
			dijkstra.printBestRoute(this, selectedFile, mapPrinter,
									mapPrinter.findCityByName(cities, sourceCity),
									mapPrinter.findCityByName(cities, targetCity));
			
		}
		
	}
	
}