import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		
		JFrame screen = new GUI();

	}

}
