import java.awt.Graphics;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MapPrinter {
	
	public void print( Graphics graphics, File file ) {
		
		List<City> cities = getCities(file);
		List<Route> routes = getRoutes(file, cities);
		
		printCities(graphics, cities);
		printRoutes(graphics, routes);

	}
	
	public List<City> getCities(File file) {
		
		List<City> cities = new ArrayList<City>();
		
		try {
			FileReader fileReader = new FileReader(file.getPath());
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line;
			
			try { //reading txt
				while ( (line = bufferedReader.readLine()) != null &&
						 !line.equals("")) {

					String[] splitLine = line.split(" ");
					
					City city = new City( splitLine[0], 
										  Integer.parseInt(splitLine[1]), 
										  Integer.parseInt(splitLine[2]));
					
					cities.add(city);
					
				}
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		return cities;
		
	}
	
	private List<Route> getRoutes(File file, List<City> cities){
		
		List<Route> routes = new ArrayList<Route>();
		
		try {
			FileReader fileReader = new FileReader(file.getPath());
			@SuppressWarnings("resource")
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line;
			
			try { //reading txt
				
				for( int i = 0; i < 104 ; i++ ) {
					if(i<44) {
						line = bufferedReader.readLine(); //only city names and positions
						continue;
					}
					else {
						line = bufferedReader.readLine(); //actual routes
						
						String[] splitRoute = line.split(" ");
						City citySource = findCityByName(cities, splitRoute[0]);
						City cityTarget = findCityByName(cities, splitRoute[1]);
						
						Route route = new Route(citySource.getX(),
												citySource.getY(),
												cityTarget.getX(),
												cityTarget.getY());
						
						routes.add(route);
						
					}
				}
				
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		return routes;
		
	}
	
	private void printCities(Graphics graphics, List<City> cities) {
		
		for ( City city : cities ) {
			
			graphics.drawOval(city.getX(), city.getY(), 10, 10);
			graphics.fillOval(city.getX(), city.getY(), 10, 10);
			graphics.drawString(getFormattedCityName(city.getName()),
												   city.getX()-10,
												   city.getY()-5);
		}
		
	}
	
	private void printRoutes(Graphics graphics, List<Route> routes) {
		
		for ( Route route : routes ) {
			
			graphics.drawLine(route.getSourceX(),
							  route.getSourceY(),
							  route.getTargetX(),
							  route.getTargetY());
									
		}
		
	}
	
	private String getFormattedCityName( String name ) {
		
		String[] splitName = name.split("_");
		String correctName = "";
		
		for ( String word : splitName ) {
			correctName = correctName.concat(word).concat(" ");
		}
		
		return correctName;
		
	}
	
	public City findCityByName( List<City> cities, String name ) {
		
		for ( City city : cities ) {
			if (city.getName().equals(name)){
				return city;
			}
		}
		
		return null;
		
	}
	
}