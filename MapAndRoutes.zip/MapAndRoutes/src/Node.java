import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Node {
	
	private String name;
	private Integer x;
	private Integer y;

	private List<Node> shortestPath = new LinkedList<>();
	
	private Integer distance = Integer.MAX_VALUE;
	
	Map<Node, Integer> adjacentNodes = new HashMap<>();
	
	public void addDestination(Node destination, int distance) {
		adjacentNodes.put(destination, distance);
	}
	
	public Node(String name) {
		this.name = name;
	}
	
	public Node(String name, Integer x, Integer y) {
		this.name = name;
		this.x = x;
		this.y = y;
	}

	public String getName() {
		return name;
	}

	public List<Node> getShortestPath() {
		return shortestPath;
	}

	public Integer getDistance() {
		return distance;
	}

	public Map<Node, Integer> getAdjacentNodes() {
		return adjacentNodes;
	}
	
	public void setDistance( Integer distance ) {
		this.distance = distance;
	}

	public void setShortestPath(List<Node> shortestPath) {
		this.shortestPath = shortestPath;
	}
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
	
}
