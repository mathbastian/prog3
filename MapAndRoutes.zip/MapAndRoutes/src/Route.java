
public class Route {
	
	private int sourceX;
	private int sourceY;
	
	private int targetX;
	private int targetY;
	
	public Route( int sourceX, int sourceY, int targetX, int targetY ) {
		this.sourceX = sourceX;
		this.sourceY = sourceY;
		this.targetX = targetX;
		this.targetY = targetY;
	}
	
	public int getSourceX() {
		return sourceX;
	}
	public int getSourceY() {
		return sourceY;
	}
	public int getTargetX() {
		return targetX;
	}
	public int getTargetY() {
		return targetY;
	}	

}