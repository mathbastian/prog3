/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 0175733
 */
public class Vehicle {
    
    private String marca;
    private String modelo;
    private String potencia;
    private String preco;
    
    public Vehicle (String marca, String modelo, String potencia, String preco){
        this.marca = marca;
        this.modelo = modelo;
        this.potencia = potencia;
        this.preco = preco;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getPotencia() {
        return potencia;
    }

    public String getPreco() {
        return preco;
    }
    
    
    
}
